# Ethical Threads

## Description

Ethical Threads is a web application that helps users research the sustainability and labor practices of fashion brands. Users can search for any brand and see public results about sustainability reports, carbon emissions, labor standards, and ethical sourcing — all in one place. Every search is automatically logged to a database and shown in a recent searches table.

## Target Browsers

Designed for desktop browsers. Tested on:
- Google Chrome (latest)
- Mozilla Firefox (latest)
- Microsoft Edge (latest)

---

## Developer Manual

### Project Structure

```
ethical-threads/
├── public/
│   ├── index.html       # Home page — Swiper carousel
│   ├── about.html       # About page — project purpose and target users
│   └── search.html      # Brand Search page — core functionality
├── api/
│   ├── brand-search.js  # GET /api/brand-search — calls Zenserp
│   └── brands.js        # GET + POST /api/brands — reads/writes Supabase
├── tests/
│   └── api-test.js
├── server.js            # Express entry point
└── package.json
```

### How to Install

Requires Node.js v18+.

```bash
npm install
npm start
```

Then open `http://localhost:3000` in your browser.

### Supabase Setup

Run this SQL in your Supabase SQL Editor to create the required table:

```sql
create table searches (
  id bigint generated always as identity primary key,
  created_at timestamptz default now(),
  brand_name text not null
);
```

### API Endpoints

#### GET /api/brand-search?brand=Nike
Searches Zenserp for sustainability information about a brand. Returns results array and scores object.

#### GET /api/brands
Returns the 20 most recent searches from Supabase.

#### POST /api/brands
Logs a brand name to Supabase. Body: `{ "brand_name": "Nike" }`

### How to Run Tests

```bash
npm test
```

### Known Bugs

- Scores are estimated from keyword matching only, not verified data.
- If Zenserp returns no results, all scores show as 40.
- The recent searches table has no delete functionality.

### Future Development

- [ ] Real score calculation using certification databases
- [ ] Delete searches from the UI
- [ ] Mobile responsive layout
- [ ] Duplicate search detection
